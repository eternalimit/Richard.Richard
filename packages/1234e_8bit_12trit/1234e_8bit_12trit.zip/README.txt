1 2 3 4 e — 8-bit / 12-trit test package

Richard Stein — All rights reserved (declaration).

Values: 1, 2, 3, 4, and hexadecimal e = decimal 14.
Binary strings have exactly 8 digits; ternary strings exactly 12.
Import CSV encoding columns as text to preserve leading zeros.
8-bit refers to the numeric encoding, not pixel-art style or PNG palette depth.

image.png is a newly rendered exact data table. reference.jpeg preserves the supplied live reference unchanged. The reference badge, date, hash, size, QR code and PCOM service claim are not evidence of verification of this newly created archive.

Run: python3 verify.py
This checks actual file hashes, CSV/JSON agreement and base conversions.
The local everify receipt documents this execution; no external everify/PCOM service or digital signature is claimed. The final ZIP hash is in the separately delivered external receipt, avoiding self-reference.
No repository or origin.master changes were made.
