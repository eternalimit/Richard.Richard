import csv, hashlib, json
from pathlib import Path

p=Path(__file__).resolve().parent
rows=json.loads((p/'data.json').read_text())
with (p/'data.csv').open() as f:
    csv_rows=list(csv.DictReader(f))
assert [r['item'] for r in rows]==['1','2','3','4','e']
assert len(rows)==len(csv_rows)==5
for r,c in zip(rows,csv_rows):
    assert r['value']==int(r['item'],16)
    for key,base,width in [('binary_8bit',2,8),('ternary_12trit',3,12)]:
        s=r[key]
        assert len(s)==width and set(s)<=set(str(i) for i in range(base))
        assert sum(int(d)*base**i for i,d in enumerate(reversed(s)))==r['value']
    assert c=={k:str(v) for k,v in r.items()}
manifest=json.loads((p/'sha256_manifest.json').read_text())
for name,digest in manifest.items():
    assert hashlib.sha256((p/name).read_bytes()).hexdigest()==digest, name
print(json.dumps({'numeric_roundtrip':'PASS','csv_json_agreement':'PASS','fixed_width':'PASS','sha256_files':'PASS','rows':len(rows),'hashed_files':len(manifest)}))
