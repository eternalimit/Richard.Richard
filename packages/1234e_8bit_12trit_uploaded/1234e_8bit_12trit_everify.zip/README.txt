PCOM package: 1 2 3 4 e | 8-bit | 12-trit
e is encoded as hexadecimal E = decimal 14.
12-trit values are base-3 strings padded to 12 trits.
